// generated from rosidl_typesupport_introspection_cpp/resource/idl__rosidl_typesupport_introspection_cpp.h.em
// with input from bbr_msgs:msg/VisualTarget.idl
// generated code does not contain a copyright notice

#ifndef BBR_MSGS__MSG__DETAIL__VISUAL_TARGET__ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_HPP_
#define BBR_MSGS__MSG__DETAIL__VISUAL_TARGET__ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_HPP_


#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_interface/macros.h"
#include "rosidl_typesupport_introspection_cpp/visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

// TODO(dirk-thomas) these visibility macros should be message package specific
ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
  ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_cpp, bbr_msgs, msg, VisualTarget)();

#ifdef __cplusplus
}
#endif

#endif  // BBR_MSGS__MSG__DETAIL__VISUAL_TARGET__ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_HPP_
