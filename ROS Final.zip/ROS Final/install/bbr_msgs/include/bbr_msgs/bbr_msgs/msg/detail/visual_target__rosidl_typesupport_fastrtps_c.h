// generated from rosidl_typesupport_fastrtps_c/resource/idl__rosidl_typesupport_fastrtps_c.h.em
// with input from bbr_msgs:msg/VisualTarget.idl
// generated code does not contain a copyright notice
#ifndef BBR_MSGS__MSG__DETAIL__VISUAL_TARGET__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_
#define BBR_MSGS__MSG__DETAIL__VISUAL_TARGET__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_


#include <stddef.h>
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_interface/macros.h"
#include "bbr_msgs/msg/rosidl_typesupport_fastrtps_c__visibility_control.h"
#include "bbr_msgs/msg/detail/visual_target__struct.h"
#include "fastcdr/Cdr.h"

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_bbr_msgs
bool cdr_serialize_bbr_msgs__msg__VisualTarget(
  const bbr_msgs__msg__VisualTarget * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_bbr_msgs
bool cdr_deserialize_bbr_msgs__msg__VisualTarget(
  eprosima::fastcdr::Cdr &,
  bbr_msgs__msg__VisualTarget * ros_message);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_bbr_msgs
size_t get_serialized_size_bbr_msgs__msg__VisualTarget(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_bbr_msgs
size_t max_serialized_size_bbr_msgs__msg__VisualTarget(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_bbr_msgs
bool cdr_serialize_key_bbr_msgs__msg__VisualTarget(
  const bbr_msgs__msg__VisualTarget * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_bbr_msgs
size_t get_serialized_size_key_bbr_msgs__msg__VisualTarget(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_bbr_msgs
size_t max_serialized_size_key_bbr_msgs__msg__VisualTarget(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_bbr_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_fastrtps_c, bbr_msgs, msg, VisualTarget)();

#ifdef __cplusplus
}
#endif

#endif  // BBR_MSGS__MSG__DETAIL__VISUAL_TARGET__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_
