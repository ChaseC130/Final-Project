// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from bbr_msgs:msg/VisualTarget.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "bbr_msgs/msg/visual_target.hpp"


#ifndef BBR_MSGS__MSG__DETAIL__VISUAL_TARGET__STRUCT_HPP_
#define BBR_MSGS__MSG__DETAIL__VISUAL_TARGET__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__bbr_msgs__msg__VisualTarget __attribute__((deprecated))
#else
# define DEPRECATED__bbr_msgs__msg__VisualTarget __declspec(deprecated)
#endif

namespace bbr_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct VisualTarget_
{
  using Type = VisualTarget_<ContainerAllocator>;

  explicit VisualTarget_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->x = 0l;
      this->y = 0l;
      this->width = 0l;
    }
  }

  explicit VisualTarget_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->x = 0l;
      this->y = 0l;
      this->width = 0l;
    }
  }

  // field types and members
  using _x_type =
    int32_t;
  _x_type x;
  using _y_type =
    int32_t;
  _y_type y;
  using _width_type =
    int32_t;
  _width_type width;

  // setters for named parameter idiom
  Type & set__x(
    const int32_t & _arg)
  {
    this->x = _arg;
    return *this;
  }
  Type & set__y(
    const int32_t & _arg)
  {
    this->y = _arg;
    return *this;
  }
  Type & set__width(
    const int32_t & _arg)
  {
    this->width = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    bbr_msgs::msg::VisualTarget_<ContainerAllocator> *;
  using ConstRawPtr =
    const bbr_msgs::msg::VisualTarget_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<bbr_msgs::msg::VisualTarget_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<bbr_msgs::msg::VisualTarget_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      bbr_msgs::msg::VisualTarget_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<bbr_msgs::msg::VisualTarget_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      bbr_msgs::msg::VisualTarget_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<bbr_msgs::msg::VisualTarget_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<bbr_msgs::msg::VisualTarget_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<bbr_msgs::msg::VisualTarget_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__bbr_msgs__msg__VisualTarget
    std::shared_ptr<bbr_msgs::msg::VisualTarget_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__bbr_msgs__msg__VisualTarget
    std::shared_ptr<bbr_msgs::msg::VisualTarget_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const VisualTarget_ & other) const
  {
    if (this->x != other.x) {
      return false;
    }
    if (this->y != other.y) {
      return false;
    }
    if (this->width != other.width) {
      return false;
    }
    return true;
  }
  bool operator!=(const VisualTarget_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct VisualTarget_

// alias to use template instance with default allocator
using VisualTarget =
  bbr_msgs::msg::VisualTarget_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace bbr_msgs

#endif  // BBR_MSGS__MSG__DETAIL__VISUAL_TARGET__STRUCT_HPP_
