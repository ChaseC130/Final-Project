// generated from rosidl_typesupport_fastrtps_cpp/resource/idl__rosidl_typesupport_fastrtps_cpp.hpp.em
// with input from bbr_msgs:msg/VisualTarget.idl
// generated code does not contain a copyright notice

#ifndef BBR_MSGS__MSG__DETAIL__VISUAL_TARGET__ROSIDL_TYPESUPPORT_FASTRTPS_CPP_HPP_
#define BBR_MSGS__MSG__DETAIL__VISUAL_TARGET__ROSIDL_TYPESUPPORT_FASTRTPS_CPP_HPP_

#include <cstddef>
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_interface/macros.h"
#include "bbr_msgs/msg/rosidl_typesupport_fastrtps_cpp__visibility_control.h"
#include "bbr_msgs/msg/detail/visual_target__struct.hpp"

#ifndef _WIN32
# pragma GCC diagnostic push
# pragma GCC diagnostic ignored "-Wunused-parameter"
# ifdef __clang__
#  pragma clang diagnostic ignored "-Wdeprecated-register"
#  pragma clang diagnostic ignored "-Wreturn-type-c-linkage"
# endif
#endif
#ifndef _WIN32
# pragma GCC diagnostic pop
#endif

#include "fastcdr/Cdr.h"

namespace bbr_msgs
{

namespace msg
{

namespace typesupport_fastrtps_cpp
{

bool
ROSIDL_TYPESUPPORT_FASTRTPS_CPP_PUBLIC_bbr_msgs
cdr_serialize(
  const bbr_msgs::msg::VisualTarget & ros_message,
  eprosima::fastcdr::Cdr & cdr);

bool
ROSIDL_TYPESUPPORT_FASTRTPS_CPP_PUBLIC_bbr_msgs
cdr_deserialize(
  eprosima::fastcdr::Cdr & cdr,
  bbr_msgs::msg::VisualTarget & ros_message);

size_t
ROSIDL_TYPESUPPORT_FASTRTPS_CPP_PUBLIC_bbr_msgs
get_serialized_size(
  const bbr_msgs::msg::VisualTarget & ros_message,
  size_t current_alignment);

size_t
ROSIDL_TYPESUPPORT_FASTRTPS_CPP_PUBLIC_bbr_msgs
max_serialized_size_VisualTarget(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

bool
ROSIDL_TYPESUPPORT_FASTRTPS_CPP_PUBLIC_bbr_msgs
cdr_serialize_key(
  const bbr_msgs::msg::VisualTarget & ros_message,
  eprosima::fastcdr::Cdr &);

size_t
ROSIDL_TYPESUPPORT_FASTRTPS_CPP_PUBLIC_bbr_msgs
get_serialized_size_key(
  const bbr_msgs::msg::VisualTarget & ros_message,
  size_t current_alignment);

size_t
ROSIDL_TYPESUPPORT_FASTRTPS_CPP_PUBLIC_bbr_msgs
max_serialized_size_key_VisualTarget(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

}  // namespace typesupport_fastrtps_cpp

}  // namespace msg

}  // namespace bbr_msgs

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_FASTRTPS_CPP_PUBLIC_bbr_msgs
const rosidl_message_type_support_t *
  ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_fastrtps_cpp, bbr_msgs, msg, VisualTarget)();

#ifdef __cplusplus
}
#endif

#endif  // BBR_MSGS__MSG__DETAIL__VISUAL_TARGET__ROSIDL_TYPESUPPORT_FASTRTPS_CPP_HPP_
