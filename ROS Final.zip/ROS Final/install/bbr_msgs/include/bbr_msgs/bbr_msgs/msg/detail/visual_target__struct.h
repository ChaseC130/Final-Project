// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from bbr_msgs:msg/VisualTarget.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "bbr_msgs/msg/visual_target.h"


#ifndef BBR_MSGS__MSG__DETAIL__VISUAL_TARGET__STRUCT_H_
#define BBR_MSGS__MSG__DETAIL__VISUAL_TARGET__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

/// Struct defined in msg/VisualTarget in the package bbr_msgs.
typedef struct bbr_msgs__msg__VisualTarget
{
  int32_t x;
  int32_t y;
  int32_t width;
} bbr_msgs__msg__VisualTarget;

// Struct for a sequence of bbr_msgs__msg__VisualTarget.
typedef struct bbr_msgs__msg__VisualTarget__Sequence
{
  bbr_msgs__msg__VisualTarget * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} bbr_msgs__msg__VisualTarget__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // BBR_MSGS__MSG__DETAIL__VISUAL_TARGET__STRUCT_H_
