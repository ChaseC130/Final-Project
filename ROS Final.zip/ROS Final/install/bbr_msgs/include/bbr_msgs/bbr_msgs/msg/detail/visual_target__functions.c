// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from bbr_msgs:msg/VisualTarget.idl
// generated code does not contain a copyright notice
#include "bbr_msgs/msg/detail/visual_target__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


bool
bbr_msgs__msg__VisualTarget__init(bbr_msgs__msg__VisualTarget * msg)
{
  if (!msg) {
    return false;
  }
  // x
  // y
  // width
  return true;
}

void
bbr_msgs__msg__VisualTarget__fini(bbr_msgs__msg__VisualTarget * msg)
{
  if (!msg) {
    return;
  }
  // x
  // y
  // width
}

bool
bbr_msgs__msg__VisualTarget__are_equal(const bbr_msgs__msg__VisualTarget * lhs, const bbr_msgs__msg__VisualTarget * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // x
  if (lhs->x != rhs->x) {
    return false;
  }
  // y
  if (lhs->y != rhs->y) {
    return false;
  }
  // width
  if (lhs->width != rhs->width) {
    return false;
  }
  return true;
}

bool
bbr_msgs__msg__VisualTarget__copy(
  const bbr_msgs__msg__VisualTarget * input,
  bbr_msgs__msg__VisualTarget * output)
{
  if (!input || !output) {
    return false;
  }
  // x
  output->x = input->x;
  // y
  output->y = input->y;
  // width
  output->width = input->width;
  return true;
}

bbr_msgs__msg__VisualTarget *
bbr_msgs__msg__VisualTarget__create(void)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  bbr_msgs__msg__VisualTarget * msg = (bbr_msgs__msg__VisualTarget *)allocator.allocate(sizeof(bbr_msgs__msg__VisualTarget), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(bbr_msgs__msg__VisualTarget));
  bool success = bbr_msgs__msg__VisualTarget__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
bbr_msgs__msg__VisualTarget__destroy(bbr_msgs__msg__VisualTarget * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    bbr_msgs__msg__VisualTarget__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
bbr_msgs__msg__VisualTarget__Sequence__init(bbr_msgs__msg__VisualTarget__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  bbr_msgs__msg__VisualTarget * data = NULL;

  if (size) {
    data = (bbr_msgs__msg__VisualTarget *)allocator.zero_allocate(size, sizeof(bbr_msgs__msg__VisualTarget), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = bbr_msgs__msg__VisualTarget__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        bbr_msgs__msg__VisualTarget__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
bbr_msgs__msg__VisualTarget__Sequence__fini(bbr_msgs__msg__VisualTarget__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      bbr_msgs__msg__VisualTarget__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

bbr_msgs__msg__VisualTarget__Sequence *
bbr_msgs__msg__VisualTarget__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  bbr_msgs__msg__VisualTarget__Sequence * array = (bbr_msgs__msg__VisualTarget__Sequence *)allocator.allocate(sizeof(bbr_msgs__msg__VisualTarget__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = bbr_msgs__msg__VisualTarget__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
bbr_msgs__msg__VisualTarget__Sequence__destroy(bbr_msgs__msg__VisualTarget__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    bbr_msgs__msg__VisualTarget__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
bbr_msgs__msg__VisualTarget__Sequence__are_equal(const bbr_msgs__msg__VisualTarget__Sequence * lhs, const bbr_msgs__msg__VisualTarget__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!bbr_msgs__msg__VisualTarget__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
bbr_msgs__msg__VisualTarget__Sequence__copy(
  const bbr_msgs__msg__VisualTarget__Sequence * input,
  bbr_msgs__msg__VisualTarget__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(bbr_msgs__msg__VisualTarget);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    bbr_msgs__msg__VisualTarget * data =
      (bbr_msgs__msg__VisualTarget *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!bbr_msgs__msg__VisualTarget__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          bbr_msgs__msg__VisualTarget__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!bbr_msgs__msg__VisualTarget__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
