// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef BBR_MSGS__MSG__VISUAL_TARGET_HPP_
#define BBR_MSGS__MSG__VISUAL_TARGET_HPP_

#include "bbr_msgs/msg/detail/visual_target__struct.hpp"
#include "bbr_msgs/msg/detail/visual_target__builder.hpp"
#include "bbr_msgs/msg/detail/visual_target__traits.hpp"
#include "bbr_msgs/msg/detail/visual_target__type_support.hpp"

#endif  // BBR_MSGS__MSG__VISUAL_TARGET_HPP_
