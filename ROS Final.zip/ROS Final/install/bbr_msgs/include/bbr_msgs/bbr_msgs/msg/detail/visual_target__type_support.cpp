// generated from rosidl_typesupport_introspection_cpp/resource/idl__type_support.cpp.em
// with input from bbr_msgs:msg/VisualTarget.idl
// generated code does not contain a copyright notice

#include "array"
#include "cstddef"
#include "string"
#include "vector"
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_cpp/message_type_support.hpp"
#include "rosidl_typesupport_interface/macros.h"
#include "bbr_msgs/msg/detail/visual_target__functions.h"
#include "bbr_msgs/msg/detail/visual_target__struct.hpp"
#include "rosidl_typesupport_introspection_cpp/field_types.hpp"
#include "rosidl_typesupport_introspection_cpp/identifier.hpp"
#include "rosidl_typesupport_introspection_cpp/message_introspection.hpp"
#include "rosidl_typesupport_introspection_cpp/message_type_support_decl.hpp"
#include "rosidl_typesupport_introspection_cpp/visibility_control.h"

namespace bbr_msgs
{

namespace msg
{

namespace rosidl_typesupport_introspection_cpp
{

void VisualTarget_init_function(
  void * message_memory, rosidl_runtime_cpp::MessageInitialization _init)
{
  new (message_memory) bbr_msgs::msg::VisualTarget(_init);
}

void VisualTarget_fini_function(void * message_memory)
{
  auto typed_message = static_cast<bbr_msgs::msg::VisualTarget *>(message_memory);
  typed_message->~VisualTarget();
}

static const ::rosidl_typesupport_introspection_cpp::MessageMember VisualTarget_message_member_array[3] = {
  {
    "x",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_INT32,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(bbr_msgs::msg::VisualTarget, x),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "y",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_INT32,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(bbr_msgs::msg::VisualTarget, y),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "width",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_INT32,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(bbr_msgs::msg::VisualTarget, width),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  }
};

static const ::rosidl_typesupport_introspection_cpp::MessageMembers VisualTarget_message_members = {
  "bbr_msgs::msg",  // message namespace
  "VisualTarget",  // message name
  3,  // number of fields
  sizeof(bbr_msgs::msg::VisualTarget),
  false,  // has_any_key_member_
  VisualTarget_message_member_array,  // message members
  VisualTarget_init_function,  // function to initialize message memory (memory has to be allocated)
  VisualTarget_fini_function  // function to terminate message instance (will not free memory)
};

static const rosidl_message_type_support_t VisualTarget_message_type_support_handle = {
  ::rosidl_typesupport_introspection_cpp::typesupport_identifier,
  &VisualTarget_message_members,
  get_message_typesupport_handle_function,
  &bbr_msgs__msg__VisualTarget__get_type_hash,
  &bbr_msgs__msg__VisualTarget__get_type_description,
  &bbr_msgs__msg__VisualTarget__get_type_description_sources,
};

}  // namespace rosidl_typesupport_introspection_cpp

}  // namespace msg

}  // namespace bbr_msgs


namespace rosidl_typesupport_introspection_cpp
{

template<>
ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
get_message_type_support_handle<bbr_msgs::msg::VisualTarget>()
{
  return &::bbr_msgs::msg::rosidl_typesupport_introspection_cpp::VisualTarget_message_type_support_handle;
}

}  // namespace rosidl_typesupport_introspection_cpp

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_cpp, bbr_msgs, msg, VisualTarget)() {
  return &::bbr_msgs::msg::rosidl_typesupport_introspection_cpp::VisualTarget_message_type_support_handle;
}

#ifdef __cplusplus
}
#endif
