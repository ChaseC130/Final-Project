// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from bbr_msgs:msg/VisualTarget.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "bbr_msgs/msg/detail/visual_target__rosidl_typesupport_introspection_c.h"
#include "bbr_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "bbr_msgs/msg/detail/visual_target__functions.h"
#include "bbr_msgs/msg/detail/visual_target__struct.h"


#ifdef __cplusplus
extern "C"
{
#endif

void bbr_msgs__msg__VisualTarget__rosidl_typesupport_introspection_c__VisualTarget_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  bbr_msgs__msg__VisualTarget__init(message_memory);
}

void bbr_msgs__msg__VisualTarget__rosidl_typesupport_introspection_c__VisualTarget_fini_function(void * message_memory)
{
  bbr_msgs__msg__VisualTarget__fini(message_memory);
}

static rosidl_typesupport_introspection_c__MessageMember bbr_msgs__msg__VisualTarget__rosidl_typesupport_introspection_c__VisualTarget_message_member_array[3] = {
  {
    "x",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(bbr_msgs__msg__VisualTarget, x),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "y",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(bbr_msgs__msg__VisualTarget, y),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "width",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(bbr_msgs__msg__VisualTarget, width),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers bbr_msgs__msg__VisualTarget__rosidl_typesupport_introspection_c__VisualTarget_message_members = {
  "bbr_msgs__msg",  // message namespace
  "VisualTarget",  // message name
  3,  // number of fields
  sizeof(bbr_msgs__msg__VisualTarget),
  false,  // has_any_key_member_
  bbr_msgs__msg__VisualTarget__rosidl_typesupport_introspection_c__VisualTarget_message_member_array,  // message members
  bbr_msgs__msg__VisualTarget__rosidl_typesupport_introspection_c__VisualTarget_init_function,  // function to initialize message memory (memory has to be allocated)
  bbr_msgs__msg__VisualTarget__rosidl_typesupport_introspection_c__VisualTarget_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t bbr_msgs__msg__VisualTarget__rosidl_typesupport_introspection_c__VisualTarget_message_type_support_handle = {
  0,
  &bbr_msgs__msg__VisualTarget__rosidl_typesupport_introspection_c__VisualTarget_message_members,
  get_message_typesupport_handle_function,
  &bbr_msgs__msg__VisualTarget__get_type_hash,
  &bbr_msgs__msg__VisualTarget__get_type_description,
  &bbr_msgs__msg__VisualTarget__get_type_description_sources,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_bbr_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, bbr_msgs, msg, VisualTarget)() {
  if (!bbr_msgs__msg__VisualTarget__rosidl_typesupport_introspection_c__VisualTarget_message_type_support_handle.typesupport_identifier) {
    bbr_msgs__msg__VisualTarget__rosidl_typesupport_introspection_c__VisualTarget_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &bbr_msgs__msg__VisualTarget__rosidl_typesupport_introspection_c__VisualTarget_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
