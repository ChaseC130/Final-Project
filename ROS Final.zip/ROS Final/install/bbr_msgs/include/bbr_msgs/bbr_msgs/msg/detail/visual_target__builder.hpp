// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from bbr_msgs:msg/VisualTarget.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "bbr_msgs/msg/visual_target.hpp"


#ifndef BBR_MSGS__MSG__DETAIL__VISUAL_TARGET__BUILDER_HPP_
#define BBR_MSGS__MSG__DETAIL__VISUAL_TARGET__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "bbr_msgs/msg/detail/visual_target__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace bbr_msgs
{

namespace msg
{

namespace builder
{

class Init_VisualTarget_width
{
public:
  explicit Init_VisualTarget_width(::bbr_msgs::msg::VisualTarget & msg)
  : msg_(msg)
  {}
  ::bbr_msgs::msg::VisualTarget width(::bbr_msgs::msg::VisualTarget::_width_type arg)
  {
    msg_.width = std::move(arg);
    return std::move(msg_);
  }

private:
  ::bbr_msgs::msg::VisualTarget msg_;
};

class Init_VisualTarget_y
{
public:
  explicit Init_VisualTarget_y(::bbr_msgs::msg::VisualTarget & msg)
  : msg_(msg)
  {}
  Init_VisualTarget_width y(::bbr_msgs::msg::VisualTarget::_y_type arg)
  {
    msg_.y = std::move(arg);
    return Init_VisualTarget_width(msg_);
  }

private:
  ::bbr_msgs::msg::VisualTarget msg_;
};

class Init_VisualTarget_x
{
public:
  Init_VisualTarget_x()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_VisualTarget_y x(::bbr_msgs::msg::VisualTarget::_x_type arg)
  {
    msg_.x = std::move(arg);
    return Init_VisualTarget_y(msg_);
  }

private:
  ::bbr_msgs::msg::VisualTarget msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::bbr_msgs::msg::VisualTarget>()
{
  return bbr_msgs::msg::builder::Init_VisualTarget_x();
}

}  // namespace bbr_msgs

#endif  // BBR_MSGS__MSG__DETAIL__VISUAL_TARGET__BUILDER_HPP_
