// generated from rosidl_generator_c/resource/idl.h.em
// with input from bbr_msgs:msg/VisualTarget.idl
// generated code does not contain a copyright notice

#ifndef BBR_MSGS__MSG__VISUAL_TARGET_H_
#define BBR_MSGS__MSG__VISUAL_TARGET_H_

#include "bbr_msgs/msg/detail/visual_target__struct.h"
#include "bbr_msgs/msg/detail/visual_target__functions.h"
#include "bbr_msgs/msg/detail/visual_target__type_support.h"

#endif  // BBR_MSGS__MSG__VISUAL_TARGET_H_
