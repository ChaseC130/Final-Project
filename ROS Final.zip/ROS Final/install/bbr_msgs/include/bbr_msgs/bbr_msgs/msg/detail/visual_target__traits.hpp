// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from bbr_msgs:msg/VisualTarget.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "bbr_msgs/msg/visual_target.hpp"


#ifndef BBR_MSGS__MSG__DETAIL__VISUAL_TARGET__TRAITS_HPP_
#define BBR_MSGS__MSG__DETAIL__VISUAL_TARGET__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "bbr_msgs/msg/detail/visual_target__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace bbr_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const VisualTarget & msg,
  std::ostream & out)
{
  out << "{";
  // member: x
  {
    out << "x: ";
    rosidl_generator_traits::value_to_yaml(msg.x, out);
    out << ", ";
  }

  // member: y
  {
    out << "y: ";
    rosidl_generator_traits::value_to_yaml(msg.y, out);
    out << ", ";
  }

  // member: width
  {
    out << "width: ";
    rosidl_generator_traits::value_to_yaml(msg.width, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const VisualTarget & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: x
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "x: ";
    rosidl_generator_traits::value_to_yaml(msg.x, out);
    out << "\n";
  }

  // member: y
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "y: ";
    rosidl_generator_traits::value_to_yaml(msg.y, out);
    out << "\n";
  }

  // member: width
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "width: ";
    rosidl_generator_traits::value_to_yaml(msg.width, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const VisualTarget & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace bbr_msgs

namespace rosidl_generator_traits
{

[[deprecated("use bbr_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const bbr_msgs::msg::VisualTarget & msg,
  std::ostream & out, size_t indentation = 0)
{
  bbr_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use bbr_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const bbr_msgs::msg::VisualTarget & msg)
{
  return bbr_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<bbr_msgs::msg::VisualTarget>()
{
  return "bbr_msgs::msg::VisualTarget";
}

template<>
inline const char * name<bbr_msgs::msg::VisualTarget>()
{
  return "bbr_msgs/msg/VisualTarget";
}

template<>
struct has_fixed_size<bbr_msgs::msg::VisualTarget>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<bbr_msgs::msg::VisualTarget>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<bbr_msgs::msg::VisualTarget>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // BBR_MSGS__MSG__DETAIL__VISUAL_TARGET__TRAITS_HPP_
