// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from bbr_msgs:msg/VisualTarget.idl
// generated code does not contain a copyright notice

#include "bbr_msgs/msg/detail/visual_target__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_bbr_msgs
const rosidl_type_hash_t *
bbr_msgs__msg__VisualTarget__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0xe1, 0xfd, 0x15, 0x3e, 0x84, 0x53, 0x23, 0x8d,
      0xff, 0x97, 0x8a, 0x97, 0xae, 0x13, 0x30, 0x8e,
      0x5b, 0x72, 0xf6, 0x73, 0x9c, 0x1e, 0xd9, 0x68,
      0x6d, 0x97, 0x48, 0x64, 0x59, 0xc2, 0xc0, 0x5e,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types

// Hashes for external referenced types
#ifndef NDEBUG
#endif

static char bbr_msgs__msg__VisualTarget__TYPE_NAME[] = "bbr_msgs/msg/VisualTarget";

// Define type names, field names, and default values
static char bbr_msgs__msg__VisualTarget__FIELD_NAME__x[] = "x";
static char bbr_msgs__msg__VisualTarget__FIELD_NAME__y[] = "y";
static char bbr_msgs__msg__VisualTarget__FIELD_NAME__width[] = "width";

static rosidl_runtime_c__type_description__Field bbr_msgs__msg__VisualTarget__FIELDS[] = {
  {
    {bbr_msgs__msg__VisualTarget__FIELD_NAME__x, 1, 1},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT32,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {bbr_msgs__msg__VisualTarget__FIELD_NAME__y, 1, 1},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT32,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {bbr_msgs__msg__VisualTarget__FIELD_NAME__width, 5, 5},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT32,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
bbr_msgs__msg__VisualTarget__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {bbr_msgs__msg__VisualTarget__TYPE_NAME, 25, 25},
      {bbr_msgs__msg__VisualTarget__FIELDS, 3, 3},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "int32 x\n"
  "int32 y\n"
  "int32 width";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
bbr_msgs__msg__VisualTarget__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {bbr_msgs__msg__VisualTarget__TYPE_NAME, 25, 25},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 27, 27},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
bbr_msgs__msg__VisualTarget__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *bbr_msgs__msg__VisualTarget__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}
