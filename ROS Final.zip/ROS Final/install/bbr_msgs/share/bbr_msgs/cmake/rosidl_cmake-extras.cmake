# generated from rosidl_cmake/cmake/rosidl_cmake-extras.cmake.in

set(bbr_msgs_IDL_FILES "msg/VisualTarget.idl")
set(bbr_msgs_INTERFACE_FILES "msg/VisualTarget.msg")
