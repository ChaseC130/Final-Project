#!/usr/bin/env python3

import cv2
import numpy as np
import rclpy
from cv_bridge import CvBridge
from geometry_msgs.msg import Point
from rclpy.node import Node
from sensor_msgs.msg import Image
from std_msgs.msg import Bool


class LaneDetector(Node):
    def __init__(self):
        super().__init__('lane_detector')

        self.declare_parameter('image_topic', '/camera_1/image_raw')
        image_topic = self.get_parameter('image_topic').value

        self.bridge = CvBridge()
        self.sub = self.create_subscription(Image, image_topic, self.image_callback, 10)

        self.error_pub = self.create_publisher(Point, '/lane/error', 10)
        self.intersection_pub = self.create_publisher(Bool, '/lane/intersection_detected', 10)
        self.end_pub = self.create_publisher(Bool, '/lane/end_line_detected', 10)
        self.debug_pub = self.create_publisher(Image, '/lane/debug_image', 10)

        self.smoothed_error = 0.0
        self.alpha = 0.25

    def image_callback(self, msg):
        frame = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
        h, w = frame.shape[:2]

        # Only use bottom half of downward camera image
        roi = frame[int(h * 0.45):h, :]
        hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)

        # Right lane: solid white tape
        white_mask = cv2.inRange(
            hsv,
            np.array([0, 0, 150]),
            np.array([180, 70, 255])
        )

        # Left lane: dashed yellow tape
        yellow_mask = cv2.inRange(
            hsv,
            np.array([18, 70, 80]),
            np.array([38, 255, 255])
        )

        # Orange end line
        orange_mask = cv2.inRange(
            hsv,
            np.array([5, 100, 100]),
            np.array([20, 255, 255])
        )

        kernel = np.ones((5, 5), np.uint8)
        white_mask = cv2.morphologyEx(white_mask, cv2.MORPH_OPEN, kernel)
        white_mask = cv2.morphologyEx(white_mask, cv2.MORPH_CLOSE, kernel)
        yellow_mask = cv2.morphologyEx(yellow_mask, cv2.MORPH_OPEN, kernel)

        # Focus on right side for solid white lane
        right_region = white_mask[:, int(w * 0.45):w]

        contours, _ = cv2.findContours(right_region, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        msg_out = Point()
        msg_out.y = 0.0

        if contours:
            largest = max(contours, key=cv2.contourArea)
            area = cv2.contourArea(largest)

            if area > 300:
                M = cv2.moments(largest)
                if M["m00"] != 0:
                    cx = int(M["m10"] / M["m00"]) + int(w * 0.45)

                    # Robot should drive slightly left of solid white line
                    target_x = int(w * 0.68)
                    raw_error = cx - target_x

                    self.smoothed_error = (
                        self.alpha * raw_error +
                        (1.0 - self.alpha) * self.smoothed_error
                    )

                    msg_out.x = float(self.smoothed_error)
                    msg_out.y = 1.0

                    cv2.circle(roi, (cx, roi.shape[0] // 2), 8, (0, 0, 255), -1)
                    cv2.line(roi, (target_x, 0), (target_x, roi.shape[0]), (255, 0, 0), 2)

        # Intersection: lots of white/yellow visible across image
        combined = cv2.bitwise_or(white_mask, yellow_mask)
        intersection = Bool()
        intersection.data = cv2.countNonZero(combined) > 9000

        # End line: orange perpendicular tape
        end_line = Bool()
        end_line.data = cv2.countNonZero(orange_mask) > 3500

        self.error_pub.publish(msg_out)
        self.intersection_pub.publish(intersection)
        self.end_pub.publish(end_line)

        debug = roi.copy()
        white_vis = cv2.cvtColor(white_mask, cv2.COLOR_GRAY2BGR)
        yellow_vis = cv2.cvtColor(yellow_mask, cv2.COLOR_GRAY2BGR)
        debug = cv2.addWeighted(debug, 0.7, white_vis, 0.3, 0)
        debug = cv2.addWeighted(debug, 0.7, yellow_vis, 0.3, 0)

        self.debug_pub.publish(self.bridge.cv2_to_imgmsg(debug, encoding='bgr8'))


def main(args=None):
    rclpy.init(args=args)
    node = LaneDetector()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
